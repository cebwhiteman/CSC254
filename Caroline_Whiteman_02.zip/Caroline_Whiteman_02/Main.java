import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Main {


    public static void main(String[] args) {
        int maximum = 10;
        String fileName = "500.txt";
        if(args.length > 0)
            fileName = args[0];
        if(args.length > 1)
            maximum = Integer.parseInt(args[1]);
        System.out.printf("I will read up to %d records from file \"%s\"\n", maximum, fileName);

        String[] common = new String[maximum];

        int n = readFile(fileName,common);

        selectionSort(common, n);
        print(common, n); //print is a method I wrote, which is down below

        int longest = findLongest(common, n);  //call findLongest and store value that is result of method
        // in a variable called longest
        System.out.println("\nThe longest password is " + longest + " characters"); //this is a system call using the system print out

        int shortest = findShortest(common, n);
        System.out.println("\nThe shortest password is " + shortest + " characters");

        double average = findAverage(common, n);
        System.out.println("\nThe average length is " + average + " characters");


        System.out.println("The shortest words are: " + shortest);
        findWordsOfLength(common, n, shortest);

        System.out.println("The longest words are: " + longest);
        findWordsOfLength(common, n, longest);
    }

    public static int findLongest(String[] list, int n) {
        int longest = 0;
        for(int i = 0; i < n; i++) {
            if(list[i].length() > longest) {
                longest = list[i].length();

            }
        }

        return longest;
    }

    public static int findShortest(String[] list, int n) {
        int shortest = (n == 0) ? 0 : Integer.MAX_VALUE;
        for(int i = 0; i < n; i++) {
            if(list[i].length() < shortest) {
                shortest = list[i].length();

            }
        }

        return shortest;
    }

    public static double findAverage(String[] list, int n) {
        double average = 0.0;
        int sum = 0;

        for(int i = 0; i < n; i++) {
            sum += list[i].length();
        }

        average = (n == 0) ? 0 : (double) sum / n;

        return average;

    }

    public static void findWordsOfLength(String[] list, int n, int targetLength) {
        for(int i = 0; i < n; i++) {
            if (list[i].length() == targetLength) {
                System.out.println("\t" + list[i]);
            }

        }
        //need something that will hold an array of strings in the main, create an array called longestWords and
        // another array called shortestWords
        //create array with size of n
        //step through entire array and if word matches target length, copy word into new array
        //create a counter to keep track of how many words are in new array

    }

    public static int readFile(String fileName, String[] list){
        int n = 0;
        try {
            Scanner input = new Scanner(new File(fileName));
            while(input.hasNextLine() && n < list.length){
                 String s = input.nextLine();
                 s = s.trim();
                 if(s.length() > 0) {
                     list[n] = s;

                     n++;
                 }
            }

            input.close();

        } catch (FileNotFoundException e) {
            // e.printStackTrace();
            System.err.println(e.getMessage());
            System.exit(1);
        }


        return n;
    }


    static void print(String[] list, int n){
        System.out.println("---------------------");
        for(int i=0; i< n;i++){
            System.out.printf("list[%d] is %s\n", i, list[i]);
        }
    }

    public static void selectionSort(String[] list, int n) {
        for(int i=0; i<n-1 ;i++) {
            String currentMin = list[i];
            int currentMinIndex = i;

            for(int j = i+1; j < n; j++){
                if(currentMin.compareTo(list[j]) > 0) {
                    currentMin = list[j];
                    currentMinIndex = j;
                }
            }
            if(currentMinIndex != i){
                list[currentMinIndex] = list[i];
                list[i] = currentMin;
            }

        }
    }
}


