import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {
    final static double DELTA = 0.0001;

    @Test
    void findLongest() {
        String[] words = new String[10]; //getting array from file
        int n = Main.readFile("500.txt", words);
        assertEquals(8, Main.findLongest(words, 8));

        String[] a = {"lettuce", "avocados"}; //setting up some other arrays to test
        String[] b = {};
        String[] c = {"radishes"};
        String[] d = {"carrot"};
        String[] e = {null, null};

        assertEquals("avocados".length(), Main.findLongest(a, a.length));
        assertEquals(0, Main.findLongest(b, 0));
        assertEquals("radishes".length(), Main.findLongest(c, c.length));
        assertEquals("carrot".length(), Main.findLongest(d, d.length));
        assertEquals(0, Main.findLongest(e, 0));
    }
        @Test
        void findShortest () {
            String[] words = new String[10];
            int n = Main.readFile("500.txt", words);
            assertEquals(4, Main.findShortest(words, 4));

            String[] a = {"apple", "kiwi"};
            String[] b = {};
            String[] c = {"orange"};
            String[] d = {"pineapple"};
            String[] e = {null, null};

            assertEquals("kiwi".length(), Main.findShortest(a, a.length));
            assertEquals(0, Main.findShortest(b, 0));
            assertEquals("orange".length(), Main.findShortest(c, c.length));
            assertEquals("pineapple".length(), Main.findShortest(d, d.length));
            assertEquals(0, Main.findShortest(e, 0));
        }


        @Test
        void findAverage () {
            String[] words = new String[10];
            int n = Main.readFile("500.txt", words);
            assertEquals(6.1, Main.findAverage(words, 10), DELTA);

            String[] a = {"miso", "edamame"};
            String[] b = {};
            String[] c = {"agedashi", "tofu"};
            String[] d = {"gyoza", "yakitori", "shumai"};
            String[] e = {null, null};

            assertEquals(5.5, Main.findAverage(a, a.length), DELTA);
            assertEquals(0, Main.findAverage(b, 0), DELTA);
            assertEquals(6, Main.findAverage(c, c.length), DELTA);
            assertEquals(6.3333, Main.findAverage(d, d.length), DELTA);
            assertEquals(0, Main.findAverage(e, 0), DELTA);
        }

        @Test
        void findWordsOfLength () {
        }


        @Test
        void readFile () {
        }

        @Test
        void selectionSort () {
        }


    }