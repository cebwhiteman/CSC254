import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int lineCount = 0;
        int sumLength = 0;
        int longestSoFar = 0;
        int shortestSoFar = Integer.MAX_VALUE;
        int onCommonList = 0;

        //looking to see how many userPasswords are on common list

        //TODO get shortest password length on userPasswords
        //TODO find and delete dead code

        int maximum = 500;
        String fileName = "common.txt"; //sets default file name
        String fileName2 = "userPasswords.txt";
        if (args.length > 0) //if there's at least one argument
            fileName = args[0]; //then get args[0]
        if (args.length > 1) //if there's a second argument
            maximum = Integer.parseInt(args[1]);
        if (args.length > 2) //if there's a third argument
            fileName2 = args[2];
        System.out.printf("\nI will read up to %d records from file \"%s\"\n", maximum, fileName);

        String[] common = new String[maximum];

        int n = readFile(fileName, common);
        selectionSort(common, n);

        try {
            Scanner input = new Scanner(new File(fileName2));
            while (input.hasNextLine()) {
                String userMDP = input.nextLine().trim();
                if (userMDP.length() > 0) {
                    lineCount++;
                    if(lineCount % 100000 == 0) {
                        System.out.println(lineCount);
                    }
                    sumLength += userMDP.length(); //as each userMDP comes through, it adds the length of the password to
                    //the sumLength, which is later used to find the average
                    if (userMDP.length() > longestSoFar)
                        longestSoFar = userMDP.length();
                    if(find(userMDP, common, n) > -1) { //userPasswords is called userMDP in this method
                        onCommonList++;
                    }
                    if(userMDP.length() < shortestSoFar) {
                        shortestSoFar = userMDP.length();
                    }
                }
            }
            input.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        //reporting

        System.out.printf("\n%d lines were read.  The average length was %1.1f\n",
                lineCount, (double) sumLength / lineCount);
        System.out.printf("\nThe longest password was %d characters\n", longestSoFar);
        System.out.printf("\nThe shortest password was %d characters\n", shortestSoFar);
        System.out.printf("\nThere were %d user passwords ", lineCount);
        System.out.printf("\n%d of user passwords were on the common list", onCommonList);
        System.out.printf("\n%1.3f%% of user passwords were on the common list", percentageOnList(onCommonList, lineCount));

    }


    public static int readFile(String fileName, String[] list) {
        int n = 0;
        try {
            Scanner input = new Scanner(new File(fileName));
            while (input.hasNextLine() && n < list.length) {
                String s = input.nextLine();
                s = s.trim();
                if (s.length() > 0) {
                    list[n] = s;

                    n++;
                }
            }

            input.close();

        } catch (FileNotFoundException e) {
            // e.printStackTrace();
            System.err.println(e.getMessage());
            System.exit(1);
        }


        return n;
    }


    static void print(String[] list, int n) {
        System.out.println("---------------------");
        for (int i = 0; i < n; i++) {
            System.out.printf("list[%d] is %s\n", i, list[i]);
        }
    }

    public static void selectionSort(String[] list, int n) {
        for (int i = 0; i < n - 1; i++) {
            String currentMin = list[i];
            int currentMinIndex = i;

            for (int j = i + 1; j < n; j++) {
                if (currentMin.compareTo(list[j]) > 0) {
                    currentMin = list[j];
                    currentMinIndex = j;
                }
            }
            if (currentMinIndex != i) {
                list[currentMinIndex] = list[i];
                list[i] = currentMin;
            }
        }
    }

    public static double percentageOnList(int lineCount, int onCommonList) {
        double percentage = 0;
        percentage = (100.0) * lineCount / onCommonList;
        return percentage;

    }

    public static int find(String needle, String[] common, int n) { //needle is userPasswords and haystack is common
        int foundAt = -1;

        int i = 0;
        while (i < n && foundAt == -1 && common[i].compareToIgnoreCase(needle) <= 0) { //< 0 makes this into a boolean
            if (needle.equalsIgnoreCase(common[i])) {
                foundAt = i;
            }
            i++;
        }

        return foundAt;
    }
}





